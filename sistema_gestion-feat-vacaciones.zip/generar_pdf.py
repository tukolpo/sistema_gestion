import os
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether
from reportlab.lib.units import inch

pdf_filename = r"c:\Users\rusbe\Desktop\sistema_gestion-feat-vacaciones\Guia_Defensa_Valery_Sistema_Gestion.pdf"

doc = SimpleDocTemplate(
    pdf_filename,
    pagesize=letter,
    rightMargin=40,
    leftMargin=40,
    topMargin=40,
    bottomMargin=40
)

styles = getSampleStyleSheet()

primary_color = colors.HexColor("#1E3A8A")
secondary_color = colors.HexColor("#2563EB")
dark_text = colors.HexColor("#1F2937")

title_style = ParagraphStyle(
    'DocTitle',
    parent=styles['Heading1'],
    fontName='Helvetica-Bold',
    fontSize=22,
    leading=26,
    textColor=primary_color,
    alignment=1,
    spaceAfter=10
)

subtitle_style = ParagraphStyle(
    'DocSubtitle',
    parent=styles['Normal'],
    fontName='Helvetica-Oblique',
    fontSize=12,
    leading=16,
    textColor=colors.HexColor("#4B5563"),
    alignment=1,
    spaceAfter=20
)

h1_style = ParagraphStyle(
    'SectionH1',
    parent=styles['Heading2'],
    fontName='Helvetica-Bold',
    fontSize=14,
    leading=18,
    textColor=primary_color,
    spaceBefore=14,
    spaceAfter=6
)

h2_style = ParagraphStyle(
    'SectionH2',
    parent=styles['Heading3'],
    fontName='Helvetica-Bold',
    fontSize=11,
    leading=14,
    textColor=secondary_color,
    spaceBefore=10,
    spaceAfter=4
)

body_style = ParagraphStyle(
    'BodyDark',
    parent=styles['BodyText'],
    fontName='Helvetica',
    fontSize=10,
    leading=14,
    textColor=dark_text,
    spaceAfter=6
)

bold_body_style = ParagraphStyle(
    'BoldBodyDark',
    parent=body_style,
    fontName='Helvetica-Bold'
)

code_style = ParagraphStyle(
    'CodeStyle',
    parent=styles['Code'],
    fontName='Courier-Bold',
    fontSize=9.5,
    leading=13,
    textColor=colors.HexColor("#111827"),
    backColor=colors.HexColor("#E5E7EB"),
    spaceAfter=6,
    leftIndent=10,
    rightIndent=10,
    borderPadding=6
)

story = []

story.append(Paragraph("GUÍA COMPLETA DE DEFENSA Y MANUAL DEL SISTEMA", title_style))
story.append(Paragraph("Proyecto: Sistema de Gestión DSI · Preparado para la Evaluación de Valery", subtitle_style))
story.append(HRFlowable(width="100%", thickness=1.5, color=primary_color, spaceAfter=15))

story.append(Paragraph("1. RESUMEN EJECUTIVO Y ESTADO DEL SISTEMA", h1_style))
story.append(Paragraph(
    "El sistema de gestión se encuentra <b>100% verificado y consolidado</b> en la carpeta del proyecto <code>sistema_gestion-feat-vacaciones</code>. "
    "Se solucionaron todos los errores de dependencias de base de datos, rutas de ejecución y autenticación de usuarios. "
    "El sistema ejecuta chequeos sin ningún fallo (<code>0 issues</code>) y está listo para ser presentado.", body_style))

story.append(Spacer(1, 10))

data_credenciales = [
    [Paragraph("<b>Parámetro</b>", bold_body_style), Paragraph("<b>Valor para la Prueba</b>", bold_body_style)],
    [Paragraph("URL del Sistema", body_style), Paragraph("<b>http://127.0.0.1:8000/</b>", body_style)],
    [Paragraph("Correo de Acceso", body_style), Paragraph("<b>admin@admin.com</b>", body_style)],
    [Paragraph("Contraseña", body_style), Paragraph("<b>admin123</b>", body_style)],
    [Paragraph("Rol asignado", body_style), Paragraph("Administrador (Nivel 1 / Control Total)", body_style)],
]
t_cred = Table(data_credenciales, colWidths=[2.0*inch, 4.5*inch])
t_cred.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), primary_color),
    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
    ('ALIGN', (0,0), (-1,-1), 'LEFT'),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#D1D5DB")),
    ('BACKGROUND', (0,1), (-1,-1), colors.HexColor("#F9FAFB")),
    ('PADDING', (0,0), (-1,-1), 6),
]))
story.append(t_cred)
story.append(Spacer(1, 15))

story.append(Paragraph("2. BANCO DE PREGUNTAS Y DEFENSA ANTE LA PROFESORA", h1_style))
story.append(Paragraph("Valery puede utilizar estas explicaciones técnicas exactas si la profesora le pregunta durante la evaluación:", body_style))

preguntas = [
    ("P: ¿Con qué Base de Datos trabaja el proyecto?",
     "R: El proyecto está configurado nativamente para trabajar con <b>PostgreSQL</b> (Motor: <code>django.db.backends.postgresql</code>, Base de Datos: <code>prueba</code>, Usuario: <code>postgres</code>, Puerto: <code>5432</code>). Además, el archivo <code>core/settings.py</code> cuenta con un detector dinámico que permite levantar un entorno de respaldo en caliente para pruebas si no estuviera encendido el servicio PostgreSQL."),
    
    ("P: ¿Por qué en la pantalla de inicio pide Correo en vez de Usuario?",
     "R: Porque implementamos el backend personalizado <code>EmailBackend</code> e hicimos heredar el modelo de usuario de <code>AbstractUser</code> de Django. Por buenas prácticas de seguridad e identidad moderna, la autenticación principal se realiza mediante correo electrónico único (<code>admin@admin.com</code>)."),
    
    ("P: ¿Dónde está el archivo de respaldo de PostgreSQL?",
     "R: El script completo con la estructura y datos de la base de datos PostgreSQL se encuentra en la raíz del proyecto bajo el nombre de <code>base_de_datos_completa.sql</code>. Se puede restaurar en cualquier instancia con el comando: <code>psql -U postgres -d prueba -f base_de_datos_completa.sql</code>."),
    
    ("P: ¿Cómo están estructurados los módulos del sistema?",
     "R: La arquitectura es modular en Django: <code>core</code> maneja la configuración global, enrutamiento (urls) y WSGI/ASGI; <code>usuarios</code> gestiona usuarios, roles (RBAC) y registros de auditoría; <code>trabajadores</code> maneja la ficha del personal y archivos de medios privados.")
]

for p, r in preguntas:
    story.append(Paragraph(f"<b>{p}</b>", h2_style))
    story.append(Paragraph(r, body_style))
    story.append(Spacer(1, 4))

story.append(Spacer(1, 10))

story.append(Paragraph("3. PASO A PASO PARA LEVANTAR EL SERVIDOR (EN CUALQUIER COMPUTADORA)", h1_style))
story.append(Paragraph("1. Abrir la terminal (PowerShell, CMD o la terminal integrada de VSCode/IDE).", body_style))
story.append(Paragraph("2. Navegar a la carpeta donde se descargó o clonó el proyecto:", body_style))
story.append(Paragraph("cd sistema_gestion-feat-vacaciones", code_style))
story.append(Paragraph("3. Ejecutar el comando para iniciar el servidor:", body_style))
story.append(Paragraph("python manage.py runserver", code_style))
story.append(Paragraph("<i>(Nota: Si la terminal ya está abierta dentro de la carpeta del proyecto, simplemente se ejecuta <code>python manage.py runserver</code>).</i>", body_style))
story.append(Paragraph("4. Abrir el navegador e ingresar a <b>http://127.0.0.1:8000/</b>.", body_style))
story.append(Paragraph("5. Iniciar sesión con <b>admin@admin.com</b> / <b>admin123</b>.", body_style))

story.append(Spacer(1, 15))

story.append(Paragraph("4. GUÍA DE RESOLUCIÓN RÁPIDA ANTE IMPREVISTOS", h1_style))

imprevistos_data = [
    [Paragraph("<b>Situación / Pregunta</b>", bold_body_style), Paragraph("<b>Solución Inmediata</b>", bold_body_style)],
    [
        Paragraph("El navegador dice que la clave es incorrecta", body_style),
        Paragraph("Verificar que en el campo de usuario se esté escribiendo el correo completo <code>admin@admin.com</code> y no la palabra <code>admin</code>.", body_style)
    ],
    [
        Paragraph("La profesora pide verificar que no haya errores de configuración", body_style),
        Paragraph("Ejecutar en la terminal: <code>python manage.py check</code>. Mostrará: <i>System check identified no issues (0 silenced)</i>.", body_style)
    ],
    [
        Paragraph("La profesora solicita conectarse a su PostgreSQL local", body_style),
        Paragraph("Asegurarse de que el servicio PostgreSQL esté corriendo en el puerto 5432 y que exista la base de datos <code>prueba</code>.", body_style)
    ]
]

t_imp = Table(imprevistos_data, colWidths=[2.5*inch, 4.0*inch])
t_imp.setStyle(TableStyle([
    ('BACKGROUND', (0,0), (-1,0), secondary_color),
    ('TEXTCOLOR', (0,0), (-1,0), colors.white),
    ('ALIGN', (0,0), (-1,-1), 'LEFT'),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#D1D5DB")),
    ('BACKGROUND', (0,1), (-1,-1), colors.HexColor("#FFFFFF")),
    ('PADDING', (0,0), (-1,-1), 6),
]))
story.append(t_imp)

doc.build(story)
print("PDF_REGENERATED_SUCCESSFULLY")
